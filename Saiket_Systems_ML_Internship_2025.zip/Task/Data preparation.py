# Task 1: Data Preparation for Customer Churn Prediction

import pandas as pd
from sklearn.preprocessing import LabelEncoder

# Step 1: Load the dataset
df = pd.read_csv(r'c:\Users\admin\Desktop\Saiket_Systems_ML_Internship_2025\Telco_Customer_Churn_Dataset  (1).csv')

# Step 2: Overview of dataset
print(" Dataset Shape:", df.shape)
print(" First 5 Rows:\n", df.head())

# Step 3: Check missing values
print("\n Missing Values:\n", df.isnull().sum())

# Step 4: Handle missing values
# For numerical columns, fill with median
num_cols = df.select_dtypes(include=['int64', 'float64']).columns
df[num_cols] = df[num_cols].fillna(df[num_cols].median())

# For categorical columns, fill with mode
cat_cols = df.select_dtypes(include=['object']).columns
df[cat_cols] = df[cat_cols].fillna(df[cat_cols].mode().iloc[0])

# Step 5: Encode categorical variables
label_encoders = {}
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# Step 6: Final Check
print("\n No Missing Values:\n", df.isnull().sum())
print(" Cleaned Dataset Shape:", df.shape)
